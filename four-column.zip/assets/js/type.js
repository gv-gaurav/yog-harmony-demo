window.ityped.init(document.querySelector('.ityped'),{
    strings: ['Body & Soul'],
    typeSpeed: 150,
    backSpeed: 150,
    loop: true
})




